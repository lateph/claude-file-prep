# claude-generator-file README
for code generate packaging